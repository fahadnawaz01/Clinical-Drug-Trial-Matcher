export const handler = async (event) => {
    console.log('Document Processor triggered!');
    console.log('Event:', JSON.stringify(event, null, 2));
    
    // Extract sessionId from S3 object key
    const s3Record = event.Records[0].s3;
    const objectKey = decodeURIComponent(s3Record.object.key.replace(/\+/g, ' '));
    const keyParts = objectKey.split('/');
    const sessionId = keyParts[1];
    
    console.log('SessionId:', sessionId);
    console.log('File:', keyParts.slice(2).join('/'));
    
    return {
        statusCode: 200,
        body: JSON.stringify({ message: 'Test successful', sessionId })
    };
};
